package ru.k0ras1k.ethereally.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import ru.k0ras1k.ethereally.R

class Intro2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.auth_choise)
    }
}