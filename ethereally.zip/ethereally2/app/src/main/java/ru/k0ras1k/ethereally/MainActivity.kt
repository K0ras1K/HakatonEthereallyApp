package ru.k0ras1k.ethereally

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import ru.k0ras1k.ethereally.activities.AuthChoiseActivity
import ru.k0ras1k.ethereally.activities.Intro0

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val token = getToken()

        if (token.isNullOrEmpty()) {
            // Токена нет, перенаправляем на экран авторизации/регистрации
            val intent = Intent(this, Intro0::class.java)
            startActivity(intent)
            finish()
        } else {
            // Токен есть, перенаправляем на главное меню
//            val intent = Intent(this, MainMenuActivity::class.java)
//            startActivity(intent)
//            finish()
        }
    }

    fun getToken(): String? {
        val sharedPreferences = getSharedPreferences("MyAppPreferences", Context.MODE_PRIVATE)
        return sharedPreferences.getString("jwt_token", null)
    }
}